value = 'pkg.module.value'
